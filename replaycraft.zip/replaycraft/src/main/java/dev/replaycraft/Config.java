package dev.replaycraft;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import net.fabricmc.loader.api.FabricLoader;

import java.io.IOException;
import java.nio.file.*;

/** Configurações salvas em config/replaycraft.json. */
public final class Config {
    // ---- câmera ----
    public double speed = 12;          // blocos por segundo
    public double sprintMult = 3;      // multiplicador ao segurar correr
    public int smoothing = 4;          // suavização do movimento (0 = instantâneo)
    public int rotSmoothing = 2;       // suavização do mouse (0 = instantâneo)
    public int freecamFov = 70;        // FOV usado durante a freecam (30..110)
    public boolean showPlayer = true;  // mostra seu corpo durante a freecam
    public boolean hideHud = false;    // esconde HUD durante a freecam

    // ---- panorama 360 ----
    public int panoWidth = 4096;       // largura (altura = metade)
    public boolean panoHideHud = true;

    // ---- gravação (índices em Recorder.*) ----
    public int recEncoder = 0;         // 0 x264, 1 x265, 2 NVENC h264, 3 NVENC hevc, 4 AMF, 5 ProRes
    public int recQuality = 2;         // 0 rascunho, 1 alta, 2 máxima, 3 quase sem perdas
    public int recFpsIdx = 2;          // índice em Recorder.FPS (60)
    public int recScale = 0;           // 0 nativa, 1 1080p, 2 1440p, 3 4K
    public int recPreset = 1;          // 0 rápido, 1 equilibrado, 2 lento
    public boolean recHideHud = false;
    public boolean recShowTimer = false; // aparece NO vídeo se ligado
    public boolean recSwapRB = false;    // ligue se as cores saírem trocadas (azul <-> vermelho)
    public String ffmpegPath = "";       // opcional: caminho completo do ffmpeg

    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static Config instance;

    private static Path file() { return FabricLoader.getInstance().getConfigDir().resolve("replaycraft.json"); }

    public static Config get() { if (instance == null) load(); return instance; }

    public static void load() {
        try {
            Path f = file();
            instance = Files.exists(f) ? GSON.fromJson(Files.readString(f), Config.class) : new Config();
        } catch (Exception e) { instance = new Config(); }
        if (instance == null) instance = new Config();
    }

    public static void save() {
        try { Files.writeString(file(), GSON.toJson(get())); } catch (IOException e) { e.printStackTrace(); }
    }
}
