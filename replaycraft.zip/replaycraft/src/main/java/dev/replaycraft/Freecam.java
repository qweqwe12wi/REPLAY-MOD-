package dev.replaycraft;

import net.minecraft.client.Minecraft;
import net.minecraft.client.Options;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.network.chat.Component;
import net.minecraft.world.phys.Vec3;

/** Estado e física da câmera livre. Posição e rotação são atualizadas a cada frame (suave em qualquer FPS). */
public final class Freecam {
    public static boolean active;
    public static boolean frozen; // true durante a captura 360 (a câmera não se move)
    public static double x, y, z;
    public static float yaw, pitch;          // rotação exibida
    private static float targetYaw, targetPitch; // rotação desejada (mouse)

    private static double vx, vy, vz;
    private static long lastNanos;
    private static boolean savedHideGui;
    private static int savedFov;

    public static void toggle() { if (active) exit(); else enter(); }

    public static void enter() {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null || active) return;
        resetToPlayer();
        vx = vy = vz = 0; lastNanos = 0;
        savedHideGui = mc.options.hideGui;
        savedFov = mc.options.fov().get();
        if (Config.get().hideHud) mc.options.hideGui = true;
        active = true;
        msg("Câmera livre: ligada");
    }

    public static void exit() {
        if (!active) return;
        active = false;
        Options o = Minecraft.getInstance().options;
        o.hideGui = savedHideGui;
        o.fov().set(savedFov);
        msg("Câmera livre: desligada");
    }

    public static void resetToPlayer() {
        LocalPlayer p = Minecraft.getInstance().player;
        if (p == null) return;
        Vec3 e = p.getEyePosition();
        x = e.x; y = e.y; z = e.z;
        setRotation(p.getYRot(), p.getXRot());
    }

    public static void setRotation(float yawDeg, float pitchDeg) {
        yaw = targetYaw = yawDeg;
        pitch = targetPitch = pitchDeg;
    }

    public static void changeSpeed(double factor) {
        Config c = Config.get();
        c.speed = Math.max(1, Math.min(100, c.speed * factor));
        Config.save();
        msg(String.format("Velocidade: %.0f blocos/s", c.speed));
    }

    /** Rotação pelo mouse (valores crus, iguais aos de Entity.turn). */
    public static void turn(double dYaw, double dPitch) {
        if (frozen) return;
        targetYaw += (float) (dYaw * 0.15);
        targetPitch = Math.max(-90f, Math.min(90f, targetPitch + (float) (dPitch * 0.15)));
    }

    /** Chamado uma vez por frame pelo mixin da câmera. */
    public static void update() {
        if (frozen) { lastNanos = 0; return; }
        long now = System.nanoTime();
        double dt = lastNanos == 0 ? 0 : Math.min((now - lastNanos) / 1e9, 0.1);
        lastNanos = now;

        Minecraft mc = Minecraft.getInstance();
        Options o = mc.options;
        Config c = Config.get();

        // FOV da freecam
        int fov = Math.max(30, Math.min(110, c.freecamFov));
        if (o.fov().get() != fov) o.fov().set(fov);

        // rotação suavizada
        double rtau = c.rotSmoothing * 0.03;
        double ra = rtau <= 0 ? 1 : 1 - Math.exp(-dt / rtau);
        yaw += (targetYaw - yaw) * ra;
        pitch += (targetPitch - pitch) * ra;

        // movimento
        double fwd = 0, str = 0, vert = 0;
        if (mc.screen == null) {
            fwd = axis(o.keyUp.isDown(), o.keyDown.isDown());
            str = axis(o.keyRight.isDown(), o.keyLeft.isDown());
            vert = axis(o.keyJump.isDown(), o.keyShift.isDown());
        }
        double yr = Math.toRadians(yaw), pr = Math.toRadians(pitch);
        double fx = -Math.sin(yr) * Math.cos(pr), fy = -Math.sin(pr), fz = Math.cos(yr) * Math.cos(pr);
        double rx = -Math.cos(yr), rz = -Math.sin(yr);

        double dx = fx * fwd + rx * str, dy = fy * fwd + vert, dz = fz * fwd + rz * str;
        double len = Math.sqrt(dx * dx + dy * dy + dz * dz);
        double sp = c.speed * (o.keySprint.isDown() ? c.sprintMult : 1);
        double tx = 0, ty = 0, tz = 0;
        if (len > 1e-6) { tx = dx / len * sp; ty = dy / len * sp; tz = dz / len * sp; }

        double tau = c.smoothing * 0.04;
        double a = tau <= 0 ? 1 : 1 - Math.exp(-dt / tau);
        vx += (tx - vx) * a; vy += (ty - vy) * a; vz += (tz - vz) * a;
        x += vx * dt; y += vy * dt; z += vz * dt;
    }

    private static double axis(boolean pos, boolean neg) { return (pos ? 1 : 0) - (neg ? 1 : 0); }

    public static void msg(String s) {
        LocalPlayer p = Minecraft.getInstance().player;
        if (p != null) p.displayClientMessage(Component.literal(s), true);
    }
}
