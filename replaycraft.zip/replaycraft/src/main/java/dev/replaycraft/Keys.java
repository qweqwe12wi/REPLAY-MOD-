package dev.replaycraft;

import com.mojang.blaze3d.platform.InputConstants;
import net.fabricmc.fabric.api.client.keymapping.v1.KeyMappingHelper;
import net.minecraft.client.KeyMapping;
import net.minecraft.resources.Identifier;
import org.lwjgl.glfw.GLFW;

import java.util.List;

/** Teclas do mod. Registradas como KeyMapping normal: aparecem em Controles e são salvas no options.txt. */
public final class Keys {
    public static KeyMapping TOGGLE, SPEED_UP, SPEED_DOWN, PANO, RESET, MENU, RECORD;
    public static List<KeyMapping> ALL;

    public static void init() {
        var cat = KeyMapping.Category.register(Identifier.fromNamespaceAndPath("replaycraft", "main"));
        TOGGLE     = reg("toggle",     GLFW.GLFW_KEY_F7, cat);
        SPEED_UP   = reg("speed_up",   GLFW.GLFW_KEY_RIGHT_BRACKET, cat);
        SPEED_DOWN = reg("speed_down", GLFW.GLFW_KEY_LEFT_BRACKET, cat);
        PANO       = reg("pano",       GLFW.GLFW_KEY_F8, cat);
        RESET      = reg("reset",      GLFW.GLFW_KEY_F9, cat);
        MENU       = reg("menu",       GLFW.GLFW_KEY_RIGHT_SHIFT, cat);
        RECORD     = reg("record",     GLFW.GLFW_KEY_F10, cat);
        ALL = List.of(TOGGLE, SPEED_UP, SPEED_DOWN, RESET, PANO, RECORD, MENU);
    }

    private static KeyMapping reg(String id, int key, KeyMapping.Category cat) {
        return KeyMappingHelper.registerKeyMapping(new KeyMapping("key.replaycraft." + id, InputConstants.Type.KEYSYM, key, cat));
    }
}
