package dev.replaycraft;

import com.mojang.blaze3d.platform.NativeImage;
import net.minecraft.client.Minecraft;
import net.minecraft.client.Screenshot;

import java.nio.file.Files;
import java.nio.file.Path;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.concurrent.CompletableFuture;
import java.util.stream.IntStream;

/**
 * Panorama 360° equirretangular: tira 6 fotos (cubo, FOV 90°) com a câmera parada, recorta o quadrado central
 * de cada uma e costura tudo em uma imagem 2:1 numa thread separada. Resultado em screenshots/360/.
 */
public final class Panorama360 {
    // {yaw, pitch} de cada face: frente, direita(+X), trás, esquerda(-X), cima, baixo
    private static final float[][] FACES = {{0, 0}, {-90, 0}, {180, 0}, {90, 0}, {0, -90}, {0, 90}};
    private static final int SETTLE_TICKS = 4; // ticks para o jogo desenhar um frame com a nova pose

    private static boolean running, awaiting, wasActive;
    private static int stage, wait;
    private static int[][] faces;
    private static int faceSize;
    private static float savedYaw, savedPitch;
    private static int savedFov;
    private static boolean savedHideGui;

    public static boolean isRunning() { return running; }

    public static void start() {
        Minecraft mc = Minecraft.getInstance();
        if (running || mc.player == null) return;
        wasActive = Freecam.active;
        if (!wasActive) Freecam.enter();
        savedYaw = Freecam.yaw; savedPitch = Freecam.pitch;
        savedFov = mc.options.fov().get();
        savedHideGui = mc.options.hideGui;
        mc.options.fov().set(90);
        if (Config.get().panoHideHud) mc.options.hideGui = true;
        if (mc.screen != null) mc.setScreenAndShow(null);
        Freecam.frozen = true;
        faces = new int[6][];
        stage = 0; wait = -1; awaiting = false; running = true;
    }

    public static void abort() { if (running) finish(false); }

    /** Chamado todo tick de cliente. */
    public static void tick() {
        if (!running) return;
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null) { finish(false); return; }
        if (awaiting) return;
        if (stage >= 6) { finish(true); return; }

        if (wait < 0) { // posiciona a câmera na face atual e espera alguns frames
            Freecam.setRotation(FACES[stage][0], FACES[stage][1]);
            wait = SETTLE_TICKS;
            return;
        }
        if (wait-- > 0) return;

        awaiting = true;
        final int myStage = stage;
        Screenshot.takeScreenshot(mc.getMainRenderTarget(), img -> {
            try (img) { faces[myStage] = cropCenterSquare(img); }
            catch (Throwable t) { t.printStackTrace(); }
            stage++; wait = -1; awaiting = false;
        });
    }

    private static int[] cropCenterSquare(NativeImage img) {
        int s = Math.min(img.getWidth(), img.getHeight());
        faceSize = s;
        int x0 = (img.getWidth() - s) / 2, y0 = (img.getHeight() - s) / 2;
        int[] out = new int[s * s];
        for (int y = 0; y < s; y++) for (int x = 0; x < s; x++) out[y * s + x] = img.getPixel(x0 + x, y0 + y);
        return out;
    }

    private static void finish(boolean stitch) {
        Minecraft mc = Minecraft.getInstance();
        running = false;
        Freecam.frozen = false;
        Freecam.setRotation(savedYaw, savedPitch);
        mc.options.fov().set(savedFov);
        mc.options.hideGui = savedHideGui;
        if (!wasActive) Freecam.exit();

        if (!stitch) return;
        for (int[] f : faces) if (f == null) { Freecam.msg("Falha na captura 360°"); return; }
        final int[][] data = faces; final int s = faceSize; final int w = Config.get().panoWidth;
        Freecam.msg("Montando panorama 360°...");
        CompletableFuture.runAsync(() -> {
            try {
                Path dir = mc.gameDirectory.toPath().resolve("screenshots").resolve("360");
                Files.createDirectories(dir);
                Path file = dir.resolve("pano_" + LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd_HH-mm-ss")) + ".png");
                stitch(data, s, w, file);
                mc.execute(() -> Freecam.msg("360° salvo: " + file.getFileName()));
            } catch (Exception e) {
                e.printStackTrace();
                mc.execute(() -> Freecam.msg("Erro ao salvar o 360° (veja o log)"));
            }
        });
    }

    // ---------- costura equirretangular ----------

    private static double[][] basis(float yawDeg, float pitchDeg) {
        double y = Math.toRadians(yawDeg), p = Math.toRadians(pitchDeg);
        double[] f = {-Math.sin(y) * Math.cos(p), -Math.sin(p), Math.cos(y) * Math.cos(p)};
        double[] r = {-Math.cos(y), 0, -Math.sin(y)};
        double[] u = {r[1] * f[2] - r[2] * f[1], r[2] * f[0] - r[0] * f[2], r[0] * f[1] - r[1] * f[0]};
        return new double[][]{f, r, u};
    }

    private static void stitch(int[][] faces, int s, int w, Path file) throws Exception {
        int h = w / 2;
        double[][][] bases = new double[6][][];
        for (int i = 0; i < 6; i++) bases[i] = basis(FACES[i][0], FACES[i][1]);

        int[] out = new int[w * h];
        IntStream.range(0, h).parallel().forEach(j -> {
            double phi = Math.PI / 2 - Math.PI * (j + 0.5) / h;
            double cp = Math.cos(phi), sp = Math.sin(phi);
            for (int i = 0; i < w; i++) {
                double lam = Math.PI - 2 * Math.PI * (i + 0.5) / w; // esquerda->direita = yaw decrescente
                double dx = -Math.sin(lam) * cp, dy = sp, dz = Math.cos(lam) * cp;
                int best = 0; double bestDot = -2;
                for (int k = 0; k < 6; k++) {
                    double[] f = bases[k][0];
                    double d = dx * f[0] + dy * f[1] + dz * f[2];
                    if (d > bestDot) { bestDot = d; best = k; }
                }
                double[] r = bases[best][1], u = bases[best][2];
                double a = (dx * r[0] + dy * r[1] + dz * r[2]) / bestDot;
                double b = (dx * u[0] + dy * u[1] + dz * u[2]) / bestDot;
                out[j * w + i] = sample(faces[best], s, (a + 1) / 2 * s, (1 - b) / 2 * s);
            }
        });

        try (NativeImage img = new NativeImage(w, h, false)) {
            for (int y = 0; y < h; y++) for (int x = 0; x < w; x++) img.setPixel(x, y, out[y * w + x] | 0xFF000000);
            img.writeToFile(file);
        }
    }

    /** Bilinear por byte (não depende da ordem dos canais ARGB/ABGR). */
    private static int sample(int[] f, int s, double u, double v) {
        u -= 0.5; v -= 0.5;
        int x0 = (int) Math.floor(u), y0 = (int) Math.floor(v);
        double fx = u - x0, fy = v - y0;
        int xa = clamp(x0, s), xb = clamp(x0 + 1, s), ya = clamp(y0, s), yb = clamp(y0 + 1, s);
        int c00 = f[ya * s + xa], c10 = f[ya * s + xb], c01 = f[yb * s + xa], c11 = f[yb * s + xb];
        int res = 0;
        for (int shift = 0; shift < 32; shift += 8) {
            double top = ((c00 >>> shift) & 0xFF) * (1 - fx) + ((c10 >>> shift) & 0xFF) * fx;
            double bot = ((c01 >>> shift) & 0xFF) * (1 - fx) + ((c11 >>> shift) & 0xFF) * fx;
            res |= ((int) Math.round(top * (1 - fy) + bot * fy) & 0xFF) << shift;
        }
        return res;
    }

    private static int clamp(int v, int s) { return v < 0 ? 0 : Math.min(v, s - 1); }
}
