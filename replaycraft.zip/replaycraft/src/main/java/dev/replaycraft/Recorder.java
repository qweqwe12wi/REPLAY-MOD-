package dev.replaycraft;

import net.minecraft.client.Minecraft;
import net.minecraft.client.Screenshot;

import java.io.File;
import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.channels.Channels;
import java.nio.channels.WritableByteChannel;
import java.nio.file.Files;
import java.nio.file.Path;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.BlockingQueue;

/**
 * Gravação de vídeo direto para o FFmpeg (sem OBS).
 * A cada frame renderizado captura a imagem final; um FPS constante é garantido repetindo frames quando o jogo
 * está lento (a duração do vídeo sempre bate com o tempo real) e pulando captura quando está rápido demais.
 * A codificação roda em outro processo/thread, então o impacto no jogo é só a leitura da imagem da GPU.
 */
public final class Recorder {
    public static final String[] ENCODERS = {"H.264 (CPU)", "H.265 (CPU)", "H.264 NVIDIA (NVENC)", "H.265 NVIDIA (NVENC)", "H.264 AMD (AMF)", "ProRes 422 HQ"};
    public static final String[] QUALITIES = {"Rascunho", "Alta", "Máxima", "Quase sem perdas"};
    public static final int[] FPS = {24, 30, 60, 120};
    public static final String[] SCALES = {"Nativa (tamanho da janela)", "1080p", "1440p", "2160p (4K)"};
    public static final int[] SCALE_H = {0, 1080, 1440, 2160};
    public static final String[] PRESETS = {"Rápido", "Equilibrado", "Lento (arquivo menor)"};

    private record Frame(int[] px, int w, int h, int repeat) {}
    private static final Frame POISON = new Frame(null, 0, 0, 0);

    private static volatile boolean recording, failed;
    private static volatile String failReason = "";
    private static final BlockingQueue<Frame> queue = new ArrayBlockingQueue<>(6);

    private static Process process;
    private static Thread writer;
    private static Path folder, videoFile;
    private static long t0, submitted, framesWritten, dropped;
    private static int fps, recW, recH, inFlight;
    private static boolean savedHideGui;

    public static boolean isRecording() { return recording; }

    public static String status() {
        if (!recording) return "Parado. Pasta: <jogo>/gravacoes/";
        long secs = (System.nanoTime() - t0) / 1_000_000_000L;
        return String.format("GRAVANDO %02d:%02d  |  perdidos: %d", secs / 60, secs % 60, dropped);
    }

    public static void toggle() { if (recording) stop(); else start(); }

    public static void start() {
        Minecraft mc = Minecraft.getInstance();
        if (recording) return;
        try {
            Config c = Config.get();
            String ts = LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd_HH-mm-ss"));
            folder = mc.gameDirectory.toPath().resolve("gravacoes").resolve(ts);
            Files.createDirectories(folder);
            videoFile = folder.resolve(c.recEncoder == 5 ? "video.mov" : "video.mp4");
            fps = FPS[Math.max(0, Math.min(FPS.length - 1, c.recFpsIdx))];
            queue.clear();
            submitted = framesWritten = dropped = 0; inFlight = 0; recW = recH = 0;
            failed = false; process = null;
            t0 = System.nanoTime();
            savedHideGui = mc.options.hideGui;
            if (c.recHideHud) mc.options.hideGui = true;
            recording = true;
            Freecam.msg("Gravando em: gravacoes/" + ts);
        } catch (IOException e) {
            e.printStackTrace();
            Freecam.msg("Não consegui criar a pasta de gravação");
        }
    }

    public static void stop() {
        if (!recording) return;
        recording = false;
        Minecraft mc = Minecraft.getInstance();
        mc.options.hideGui = savedHideGui;
        try {
            if (writer != null) { queue.put(POISON); writer.join(60_000); }
            if (process != null) process.waitFor();
        } catch (InterruptedException e) { Thread.currentThread().interrupt(); }
        writer = null; process = null;
        if (framesWritten == 0) Freecam.msg("Gravação vazia (sem frames). Veja ffmpeg.log na pasta.");
        else Freecam.msg("Vídeo salvo: " + folder.getFileName() + "/" + videoFile.getFileName() + (dropped > 0 ? " (" + dropped + " frames perdidos)" : ""));
    }

    /** Todo tick: se o encoder morreu, para e avisa. */
    public static void tick() {
        if (failed) { failed = false; recording = true; stop(); Freecam.msg("Gravação parou: " + failReason); }
    }

    /** Fim de cada frame renderizado (chamado pelo MinecraftMixin). */
    public static void onFrame() {
        if (!recording || inFlight >= 2) return;
        long target = (long) ((System.nanoTime() - t0) / 1e9 * fps) + 1;
        long due = target - submitted;
        if (due <= 0) return; // jogo mais rápido que o FPS do vídeo: não precisa capturar
        submitted = target;
        inFlight++;
        final int repeat = (int) Math.min(due, 60);
        Screenshot.takeScreenshot(Minecraft.getInstance().getMainRenderTarget(), img -> {
            try (img) {
                int[] px = img.getPixels(); // int ARGB (bytes BGRA em little-endian); ver opção "trocar cores"
                submit(new Frame(px, img.getWidth(), img.getHeight(), repeat));
            } catch (Throwable t) {
                t.printStackTrace();
            } finally { inFlight--; }
        });
    }

    private static void submit(Frame f) {
        if (!recording) return;
        if (process == null) {
            try { launchFfmpeg(f.w(), f.h()); }
            catch (Exception e) { e.printStackTrace(); failReason = e.getMessage(); failed = true; recording = false; return; }
        }
        if (f.w() != recW || f.h() != recH) { dropped++; return; } // janela mudou de tamanho
        if (!queue.offer(f)) dropped++;
    }

    // ---------- FFmpeg ----------

    private static void launchFfmpeg(int w, int h) throws IOException {
        Config c = Config.get();
        recW = w; recH = h;
        List<String> cmd = new ArrayList<>(List.of(
            locateFfmpeg(c), "-y", "-hide_banner", "-loglevel", "warning",
            "-f", "rawvideo", "-pix_fmt", c.recSwapRB ? "rgba" : "bgra",
            "-s", w + "x" + h, "-framerate", String.valueOf(fps), "-i", "-"));

        int sh = SCALE_H[Math.max(0, Math.min(SCALE_H.length - 1, c.recScale))];
        cmd.add("-vf");
        cmd.add(sh > 0 ? "scale=-2:" + sh + ":flags=lanczos" : "crop=trunc(iw/2)*2:trunc(ih/2)*2");

        int[] crf = {28, 20, 16, 12};          // x264/x265
        int[] cq = {30, 22, 18, 14};           // NVENC / AMF
        int q = Math.max(0, Math.min(3, c.recQuality)), p = Math.max(0, Math.min(2, c.recPreset));
        String[] cpuPreset = {"veryfast", "medium", "slow"}, nvPreset = {"p3", "p5", "p7"}, amfQuality = {"speed", "balanced", "quality"};
        switch (c.recEncoder) {
            case 1 -> cmd.addAll(List.of("-c:v", "libx265", "-preset", cpuPreset[p], "-crf", String.valueOf(crf[q]), "-pix_fmt", "yuv420p", "-tag:v", "hvc1"));
            case 2 -> cmd.addAll(List.of("-c:v", "h264_nvenc", "-preset", nvPreset[p], "-rc", "vbr", "-cq", String.valueOf(cq[q]), "-b:v", "0", "-pix_fmt", "yuv420p"));
            case 3 -> cmd.addAll(List.of("-c:v", "hevc_nvenc", "-preset", nvPreset[p], "-rc", "vbr", "-cq", String.valueOf(cq[q]), "-b:v", "0", "-pix_fmt", "yuv420p", "-tag:v", "hvc1"));
            case 4 -> cmd.addAll(List.of("-c:v", "h264_amf", "-quality", amfQuality[p], "-rc", "cqp", "-qp_i", String.valueOf(cq[q]), "-qp_p", String.valueOf(cq[q]), "-qp_b", String.valueOf(cq[q]), "-pix_fmt", "yuv420p"));
            case 5 -> cmd.addAll(List.of("-c:v", "prores_ks", "-profile:v", "3", "-pix_fmt", "yuv422p10le"));
            default -> cmd.addAll(List.of("-c:v", "libx264", "-preset", cpuPreset[p], "-crf", String.valueOf(crf[q]), "-pix_fmt", "yuv420p"));
        }
        if (c.recEncoder != 5) cmd.addAll(List.of("-movflags", "+faststart"));
        cmd.add(videoFile.toString());

        process = new ProcessBuilder(cmd)
            .redirectErrorStream(true)
            .redirectOutput(folder.resolve("ffmpeg.log").toFile())
            .start();
        final WritableByteChannel ch = Channels.newChannel(process.getOutputStream());
        writer = Thread.ofPlatform().name("ReplayCraft-Encoder").daemon(true).start(() -> writeLoop(ch, w, h));
    }

    private static void writeLoop(WritableByteChannel ch, int w, int h) {
        ByteBuffer buf = ByteBuffer.allocateDirect(w * h * 4).order(ByteOrder.LITTLE_ENDIAN); // reaproveitado
        try {
            while (true) {
                Frame f = queue.take();
                if (f == POISON) break;
                buf.clear();
                buf.asIntBuffer().put(f.px());
                for (int i = 0; i < f.repeat(); i++) {
                    buf.position(0).limit(buf.capacity());
                    while (buf.hasRemaining()) ch.write(buf);
                    framesWritten++;
                }
            }
        } catch (IOException e) {
            failReason = "o FFmpeg fechou (veja ffmpeg.log na pasta da gravação)";
            failed = true;
        } catch (InterruptedException ignored) {
            Thread.currentThread().interrupt();
        } finally {
            try { ch.close(); } catch (IOException ignored) {}
        }
    }

    /** Ordem: caminho da config, FFMPEG_PATH, <jogo>/ffmpeg/, PATH do sistema. */
    public static String locateFfmpeg(Config c) throws IOException {
        boolean win = System.getProperty("os.name").toLowerCase().contains("win");
        String exe = win ? "ffmpeg.exe" : "ffmpeg";
        if (c.ffmpegPath != null && !c.ffmpegPath.isBlank() && Files.isExecutable(Path.of(c.ffmpegPath))) return c.ffmpegPath;
        String env = System.getenv("FFMPEG_PATH");
        if (env != null && Files.isExecutable(Path.of(env))) return env;
        Path local = Minecraft.getInstance().gameDirectory.toPath().resolve("ffmpeg").resolve(exe);
        if (Files.isExecutable(local)) return local.toString();
        String path = System.getenv("PATH");
        if (path != null) for (String dir : path.split(File.pathSeparator)) {
            Path pth = Path.of(dir, exe);
            if (Files.isExecutable(pth)) return pth.toString();
        }
        throw new IOException("FFmpeg não encontrado. Instale (ffmpeg.org) e ponha no PATH, ou coloque em <jogo>/ffmpeg/");
    }
}
