package dev.replaycraft;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayConnectionEvents;

public final class ReplayCraftClient implements ClientModInitializer {
    @Override
    public void onInitializeClient() {
        Config.load();
        Keys.init();

        ClientTickEvents.END_CLIENT_TICK.register(mc -> {
            while (Keys.TOGGLE.consumeClick()) Freecam.toggle();
            while (Keys.SPEED_UP.consumeClick()) Freecam.changeSpeed(1.25);
            while (Keys.SPEED_DOWN.consumeClick()) Freecam.changeSpeed(0.8);
            while (Keys.RESET.consumeClick()) Freecam.resetToPlayer();
            while (Keys.PANO.consumeClick()) Panorama360.start();
            while (Keys.RECORD.consumeClick()) Recorder.toggle();
            while (Keys.MENU.consumeClick()) mc.setScreenAndShow(new SettingsScreen());
            Panorama360.tick();
            Recorder.tick();
            if (Freecam.active && mc.player == null) Freecam.exit();
        });
        ClientPlayConnectionEvents.DISCONNECT.register((handler, mc) -> {
            Panorama360.abort();
            Recorder.stop();
            Freecam.exit();
        });
    }
}
