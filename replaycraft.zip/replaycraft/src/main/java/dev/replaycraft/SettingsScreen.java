package dev.replaycraft;

import com.mojang.blaze3d.platform.InputConstants;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.input.KeyEvent;
import net.minecraft.client.input.MouseButtonEvent;
import net.minecraft.network.chat.Component;
import org.lwjgl.glfw.GLFW;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Consumer;
import java.util.function.Supplier;

/**
 * Menu do mod com abas, desenhado à mão (sem widgets do vanilla).
 * Clique esquerdo avança uma opção, clique direito volta. Em "Teclas": clique e aperte a nova (ESC cancela, Backspace remove).
 * CONFIRA no jar da 26.2: GuiGraphicsExtractor#text / #fill e as assinaturas de KeyEvent / MouseButtonEvent.
 */
public final class SettingsScreen extends Screen {
    private static final int BG = 0xE0101018, PANEL = 0xF01A1A24, ROW = 0xFF252533, ROW_HOVER = 0xFF30304A,
            ACCENT = 0xFF5CB8FF, TEXT = 0xFFE6E6F0, DIM = 0xFF9A9AB0, ON = 0xFF58D68D, OFF = 0xFFE57373, REC = 0xFFFF4D4D;
    private static final String[] TABS = {"Câmera", "Gravação", "360°", "Teclas"};
    private static final int[] PANO_WIDTHS = {2048, 4096, 8192};
    private static final String[] PANO_NAMES = {"2048 x 1024", "4096 x 2048", "8192 x 4096"};
    private static int lastTab = 0;

    private abstract static class Item {
        int x, y, w, h;
        abstract void draw(SettingsScreen s, GuiGraphicsExtractor g, boolean hover);
        boolean click(double mx, double my, int btn) { return false; }
    }

    private final List<Item> items = new ArrayList<>();
    private KeyMapping listening;
    private int tab = lastTab;
    private int px, py, pw, ph, rowH;

    public SettingsScreen() { super(Component.literal("ReplayCraft")); }

    @Override public boolean isPauseScreen() { return false; }

    @Override
    protected void init() {
        rowH = height >= 300 ? 20 : 16;
        pw = 330;
        ph = 28 + 22 + 11 * (rowH + 3) + 24;
        px = (width - pw) / 2;
        py = Math.max(4, (height - ph) / 2);
        build();
    }

    private void build() {
        items.clear();
        listening = null;
        Config c = Config.get();
        int x = 12, w = pw - 24, y = 28 + 22 + 6, g = 3;
        switch (tab) {
            case 0 -> {
                y = add(step("Velocidade", () -> c.speed, v -> c.speed = v, 1, 1, 100, "%.0f blocos/s"), x, y, w, g);
                y = add(step("Turbo (correr)", () -> c.sprintMult, v -> c.sprintMult = v, 0.5, 1, 10, "x%.1f"), x, y, w, g);
                y = add(step("Suavização do movimento", () -> (double) c.smoothing, v -> c.smoothing = (int) Math.round(v), 1, 0, 10, "%.0f"), x, y, w, g);
                y = add(step("Suavização do mouse", () -> (double) c.rotSmoothing, v -> c.rotSmoothing = (int) Math.round(v), 1, 0, 10, "%.0f"), x, y, w, g);
                y = add(step("FOV da freecam", () -> (double) c.freecamFov, v -> c.freecamFov = (int) Math.round(v), 5, 30, 110, "%.0f"), x, y, w, g);
                y = add(toggle("Mostrar meu corpo", () -> c.showPlayer, v -> c.showPlayer = v), x, y, w, g);
                y = add(toggle("Esconder HUD na freecam", () -> c.hideHud, v -> c.hideHud = v), x, y, w, g);
                y = add(button(Freecam.active ? "Desligar câmera livre" : "Ligar câmera livre", true, () -> { Freecam.toggle(); build(); }), x, y, w, g);
            }
            case 1 -> {
                y = add(info(Recorder::status), x, y, w, g);
                y = add(cycle("Codificador", Recorder.ENCODERS, () -> c.recEncoder, v -> c.recEncoder = v), x, y, w, g);
                y = add(cycle("Qualidade", Recorder.QUALITIES, () -> c.recQuality, v -> c.recQuality = v), x, y, w, g);
                y = add(cycle("FPS", fpsNames(), () -> c.recFpsIdx, v -> c.recFpsIdx = v), x, y, w, g);
                y = add(cycle("Resolução do vídeo", Recorder.SCALES, () -> c.recScale, v -> c.recScale = v), x, y, w, g);
                y = add(cycle("Velocidade de codificação", Recorder.PRESETS, () -> c.recPreset, v -> c.recPreset = v), x, y, w, g);
                y = add(toggle("Esconder HUD ao gravar", () -> c.recHideHud, v -> c.recHideHud = v), x, y, w, g);
                y = add(toggle("Corrigir cores (trocar R/B)", () -> c.recSwapRB, v -> c.recSwapRB = v), x, y, w, g);
                y = add(button(Recorder.isRecording() ? "Parar gravação" : "Iniciar gravação", true, () -> { Config.save(); onClose(); Recorder.toggle(); }), x, y, w, g);
            }
            case 2 -> {
                y = add(cycle("Tamanho do panorama", PANO_NAMES, () -> idx(PANO_WIDTHS, c.panoWidth), v -> c.panoWidth = PANO_WIDTHS[v]), x, y, w, g);
                y = add(toggle("Esconder HUD na foto", () -> c.panoHideHud, v -> c.panoHideHud = v), x, y, w, g);
                y = add(button("Capturar 360° agora", true, () -> { Config.save(); onClose(); Panorama360.start(); }), x, y, w, g);
            }
            default -> {
                for (KeyMapping km : Keys.ALL) y = add(keyRow(km), x, y, w, g);
                y = add(button("Restaurar teclas padrão", false, () -> {
                    for (KeyMapping km : Keys.ALL) km.setKey(km.getDefaultKey());
                    KeyMapping.resetMapping(); Minecraft.getInstance().options.save();
                }), x, y + 4, w, g);
            }
        }
    }

    private static String[] fpsNames() {
        String[] n = new String[Recorder.FPS.length];
        for (int i = 0; i < n.length; i++) n[i] = Recorder.FPS[i] + " fps";
        return n;
    }
    private static int idx(int[] a, int v) { for (int i = 0; i < a.length; i++) if (a[i] == v) return i; return 0; }

    private int add(Item it, int x, int y, int w, int gap) { it.x = x; it.y = y; it.w = w; it.h = rowH; items.add(it); return y + rowH + gap; }

    // ---------- fábrica de itens ----------

    private Item info(Supplier<String> text) {
        return new Item() {
            @Override void draw(SettingsScreen s, GuiGraphicsExtractor g, boolean hover) {
                g.fill(px + x, py + y, px + x + w, py + y + h, 0xFF14141E);
                String t = text.get();
                s.txtCenter(g, t, px + x + w / 2, py + y + (h - 8) / 2, Recorder.isRecording() ? REC : DIM);
            }
        };
    }

    private Item toggle(String label, Supplier<Boolean> get, Consumer<Boolean> set) {
        return new Item() {
            @Override void draw(SettingsScreen s, GuiGraphicsExtractor g, boolean hover) {
                s.rowBg(g, this, hover);
                s.txt(g, label, px + x + 6, py + y + (h - 8) / 2, TEXT);
                boolean v = get.get();
                s.txtRight(g, v ? "Ligado" : "Desligado", px + x + w - 6, py + y + (h - 8) / 2, v ? ON : OFF);
            }
            @Override boolean click(double mx, double my, int btn) { set.accept(!get.get()); Config.save(); return true; }
        };
    }

    private Item step(String label, Supplier<Double> get, Consumer<Double> set, double stepBy, double min, double max, String fmt) {
        return new Item() {
            @Override void draw(SettingsScreen s, GuiGraphicsExtractor g, boolean hover) {
                s.rowBg(g, this, hover);
                int ty = py + y + (h - 8) / 2;
                s.txt(g, label, px + x + 6, ty, TEXT);
                int plusX = px + x + w - 14, valX = plusX - 74, minusX = valX - 14;
                s.box(g, minusX, py + y + 2, 12, h - 4, "-");
                s.box(g, plusX, py + y + 2, 12, h - 4, "+");
                s.txtCenter(g, String.format(fmt, get.get()), valX + 37, ty, ACCENT);
            }
            @Override boolean click(double mx, double my, int btn) {
                int plusX = px + x + w - 14, valX = plusX - 74, minusX = valX - 14;
                double v = get.get();
                if (mx >= plusX && mx <= plusX + 12) v += stepBy;
                else if (mx >= minusX && mx <= minusX + 12) v -= stepBy;
                else return false;
                set.accept(Math.max(min, Math.min(max, v))); Config.save(); return true;
            }
        };
    }

    private Item cycle(String label, String[] names, Supplier<Integer> get, Consumer<Integer> set) {
        return new Item() {
            @Override void draw(SettingsScreen s, GuiGraphicsExtractor g, boolean hover) {
                s.rowBg(g, this, hover);
                int ty = py + y + (h - 8) / 2;
                s.txt(g, label, px + x + 6, ty, TEXT);
                s.txtRight(g, names[Math.max(0, Math.min(names.length - 1, get.get()))], px + x + w - 6, ty, ACCENT);
            }
            @Override boolean click(double mx, double my, int btn) {
                int n = names.length, i = get.get();
                set.accept(btn == 1 ? (i + n - 1) % n : (i + 1) % n);
                Config.save(); return true;
            }
        };
    }

    private Item keyRow(KeyMapping km) {
        return new Item() {
            @Override void draw(SettingsScreen s, GuiGraphicsExtractor g, boolean hover) {
                s.rowBg(g, this, hover || listening == km);
                int ty = py + y + (h - 8) / 2;
                s.txt(g, Component.translatable(km.getName()).getString(), px + x + 6, ty, TEXT);
                boolean l = listening == km;
                String v = l ? "> pressione uma tecla <" : km.isUnbound() ? "Nenhuma" : km.getTranslatedKeyMessage().getString();
                s.txtRight(g, v, px + x + w - 6, ty, l ? ON : ACCENT);
            }
            @Override boolean click(double mx, double my, int btn) { listening = km; return true; }
        };
    }

    private Item button(String label, boolean accent, Runnable action) {
        return new Item() {
            @Override void draw(SettingsScreen s, GuiGraphicsExtractor g, boolean hover) {
                int col = accent ? (hover ? 0xFF7CCBFF : ACCENT) : (hover ? ROW_HOVER : ROW);
                g.fill(px + x, py + y, px + x + w, py + y + h, col);
                s.txtCenter(g, label, px + x + w / 2, py + y + (h - 8) / 2, accent ? 0xFF0B1020 : TEXT);
            }
            @Override boolean click(double mx, double my, int btn) { action.run(); return true; }
        };
    }

    // ---------- desenho ----------

    @Override
    public void extractRenderState(GuiGraphicsExtractor g, int mouseX, int mouseY, float partialTick) {
        g.fill(0, 0, width, height, BG);
        g.fill(px - 1, py - 1, px + pw + 1, py + ph + 1, ACCENT);
        g.fill(px, py, px + pw, py + ph, PANEL);
        g.fill(px, py, px + pw, py + 24, 0xFF14141E);
        txt(g, "ReplayCraft", px + 12, py + 8, TEXT);
        if (Recorder.isRecording()) txtRight(g, "REC", px + pw - 12, py + 8, REC);
        else txtRight(g, Freecam.active ? "Freecam ligada" : "Freecam desligada", px + pw - 12, py + 8, Freecam.active ? ON : DIM);

        int tw = pw / TABS.length;
        for (int i = 0; i < TABS.length; i++) {
            int tx = px + i * tw;
            boolean sel = i == tab, hov = mouseX >= tx && mouseX < tx + tw && mouseY >= py + 24 && mouseY < py + 46;
            g.fill(tx, py + 24, tx + tw, py + 46, sel ? 0xFF22223A : hov ? 0xFF1E1E30 : 0xFF181824);
            if (sel) g.fill(tx, py + 44, tx + tw, py + 46, ACCENT);
            txtCenter(g, TABS[i], tx + tw / 2, py + 31, sel ? TEXT : DIM);
        }
        for (Item it : items) {
            boolean hover = mouseX >= px + it.x && mouseX <= px + it.x + it.w && mouseY >= py + it.y && mouseY <= py + it.y + it.h;
            it.draw(this, g, hover);
        }
        txtCenter(g, "Esquerdo: próximo  |  Direito: anterior  |  ESC: fechar e salvar", px + pw / 2, py + ph - 12, DIM);
    }

    private void rowBg(GuiGraphicsExtractor g, Item it, boolean hover) {
        g.fill(px + it.x, py + it.y, px + it.x + it.w, py + it.y + it.h, hover ? ROW_HOVER : ROW);
    }
    private void box(GuiGraphicsExtractor g, int x, int y, int w, int h, String t) {
        g.fill(x, y, x + w, y + h, 0xFF3A3A55);
        txtCenter(g, t, x + w / 2, y + (h - 8) / 2, TEXT);
    }
    private void txt(GuiGraphicsExtractor g, String s, int x, int y, int c) { g.text(font, Component.literal(s), x, y, c); }
    private void txtRight(GuiGraphicsExtractor g, String s, int x, int y, int c) { g.text(font, Component.literal(s), x - font.width(s), y, c); }
    private void txtCenter(GuiGraphicsExtractor g, String s, int cx, int y, int c) { g.text(font, Component.literal(s), cx - font.width(s) / 2, y, c); }

    // ---------- entrada ----------

    @Override
    public boolean mouseClicked(MouseButtonEvent event, boolean doubleClick) {
        double mx = event.x(), my = event.y();
        int btn = event.button();
        if (listening != null) { listening = null; return true; }

        int tw = pw / TABS.length;
        if (my >= py + 24 && my < py + 46 && mx >= px && mx < px + pw) {
            tab = lastTab = Math.min(TABS.length - 1, (int) ((mx - px) / tw));
            build();
            return true;
        }
        if (btn != 0 && btn != 1) return false;
        for (Item it : items) {
            if (mx >= px + it.x && mx <= px + it.x + it.w && my >= py + it.y && my <= py + it.y + it.h) {
                if (it.click(mx, my, btn)) return true;
            }
        }
        return false;
    }

    @Override
    public boolean keyPressed(KeyEvent event) {
        if (listening != null) {
            int key = event.key();
            if (key == GLFW.GLFW_KEY_BACKSPACE) listening.setKey(InputConstants.UNKNOWN);
            else if (key != GLFW.GLFW_KEY_ESCAPE) listening.setKey(InputConstants.Type.KEYSYM.getOrCreate(key));
            KeyMapping.resetMapping();
            Minecraft.getInstance().options.save();
            listening = null;
            return true;
        }
        return super.keyPressed(event); // ESC fecha
    }

    @Override public void onClose() { Config.save(); super.onClose(); }
}
