package dev.replaycraft.mixin;

import dev.replaycraft.Config;
import dev.replaycraft.Freecam;
import net.minecraft.client.Camera;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(Camera.class)
public abstract class CameraMixin {
    // CONFIRA no jar da 26.2: assinatura exata destes dois métodos.
    @Shadow protected abstract void setPosition(double x, double y, double z);
    @Shadow protected abstract void setRotation(float yRot, float xRot);

    /** Logo depois da câmera se alinhar à entidade (antes do culling), sobrescreve pose com a da freecam. */
    @Inject(method = "alignWithEntity", at = @At("TAIL"))
    private void replaycraft$override(float partialTick, CallbackInfo ci) {
        if (!Freecam.active) return;
        Freecam.update();
        setRotation(Freecam.yaw, Freecam.pitch);
        setPosition(Freecam.x, Freecam.y, Freecam.z);
    }

    /** "Destacada" = o jogo desenha o corpo do jogador mesmo em primeira pessoa. */
    @Inject(method = "isDetached", at = @At("HEAD"), cancellable = true)
    private void replaycraft$detached(CallbackInfoReturnable<Boolean> cir) {
        if (Freecam.active && Config.get().showPlayer) cir.setReturnValue(true);
    }
}
