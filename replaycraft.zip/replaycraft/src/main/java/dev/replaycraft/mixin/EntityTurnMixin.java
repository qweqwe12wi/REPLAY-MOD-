package dev.replaycraft.mixin;

import dev.replaycraft.Freecam;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.world.entity.Entity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(Entity.class)
public abstract class EntityTurnMixin {
    /** Mouse gira a câmera, não o jogador. */
    @Inject(method = "turn(DD)V", at = @At("HEAD"), cancellable = true)
    private void replaycraft$turn(double yRot, double xRot, CallbackInfo ci) {
        if (Freecam.active && (Object) this instanceof LocalPlayer) {
            Freecam.turn(yRot, xRot);
            ci.cancel();
        }
    }
}
