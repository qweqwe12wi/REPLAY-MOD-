package dev.replaycraft.mixin;

import dev.replaycraft.Freecam;
import net.minecraft.client.player.ClientInput;
import net.minecraft.client.player.KeyboardInput;
import net.minecraft.world.entity.player.Input;
import net.minecraft.world.phys.Vec2;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(KeyboardInput.class)
public abstract class KeyboardInputMixin extends ClientInput {
    /** Zera o input do jogador enquanto a freecam está ligada (ele fica parado). */
    // CONFIRA no jar da 26.2: nomes dos campos keyPresses/moveVector em ClientInput.
    @Inject(method = "tick", at = @At("TAIL"))
    private void replaycraft$block(CallbackInfo ci) {
        if (Freecam.active) {
            this.keyPresses = Input.EMPTY;
            this.moveVector = Vec2.ZERO;
        }
    }
}
