package dev.replaycraft.mixin;

import dev.replaycraft.Recorder;
import net.minecraft.client.Minecraft;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(Minecraft.class)
public abstract class MinecraftMixin {
    /** Fim de cada frame renderizado: é aqui que o gravador captura a imagem final. */
    // CONFIRA no jar da 26.2: o método do loop de frame ainda se chama runTick(boolean)?
    @Inject(method = "runTick", at = @At("TAIL"))
    private void replaycraft$frameEnd(boolean tick, CallbackInfo ci) {
        Recorder.onFrame();
    }
}
